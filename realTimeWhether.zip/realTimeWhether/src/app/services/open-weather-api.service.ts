import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OpenWeatherApiService {
  weatherUrl = 'http://api.openweathermap.org/data/2.5/weather?';
  apikey = '&APPID=4515a7519f221c2a9f88c072033cd9d2';

  constructor(private http: HttpClient) { }

  findWeather(lat, lng): Observable<any> {
    const data = 'lat=' + lat + '&lon=' + lng;
    return  this.http.get(this.weatherUrl + '' + data + '' + this.apikey + '');
  }
}
