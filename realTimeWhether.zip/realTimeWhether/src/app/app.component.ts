import { Component , NgZone} from '@angular/core';
import * as L from 'leaflet';
import {BackendServiceService} from './services/backend-service.service';
import {mark} from '@angular/compiler-cli/src/ngtsc/perf/src/clock';
import {MatDialog} from '@angular/material';
import {WeatherCountryDetailsComponent} from './weather-country-details/weather-country-details.component';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'realTimeWhether';
  map: L.Map;
  options = {
    layers: [
      L.tileLayer('https://maps.heigit.org/openmapsurfer/tiles/roads/webmercator/{z}/{x}/{y}.png', {
        maxZoom: 18,
        attribution: '...'
      })
    ],
    zoom: 3,
    center: L.latLng(35, 45)
  };
  constructor(private backService: BackendServiceService,
              private dialog: MatDialog,
              private zone: NgZone) {
  }

  onMapReady(map: L.map) {
    this.map = map;
    this.fillMap();
  }
  fillMap() {
    const icon = L.icon({
      iconSize: [50, 41],
      iconAnchor: [13, 41],
      iconUrl: '../assets/texas (1).svg',
      popupAnchor: [17, -30]
    });
    this.backService.getAllStates().subscribe(res => {
      res.map(el => {
        const marker = L.marker([el.latitude, el.longitude], {
          icon
        }).on('dblclick', () => {
          this.zone.run( () => {
            this.dialog.open(WeatherCountryDetailsComponent, {

              data: {
                name: el.name,
                lat: el.latitude,
                lng: el.longitude
              }
            }); });
        }).on('click', () => {
          // hapet modali me detaje
          const popup = L.popup().setLatLng(el.latitude, el.longitude).setContent('test');
          marker.bindPopup(popup);
          console.log('test@123');
        }).addTo(this.map);
      });
    });

  }
}
