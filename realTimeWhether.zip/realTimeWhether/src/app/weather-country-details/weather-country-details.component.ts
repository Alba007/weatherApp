import {Component, Inject, OnInit} from '@angular/core';
import {OpenWeatherApiService} from '../services/open-weather-api.service';
import {MAT_DIALOG_DATA} from '@angular/material/dialog';


@Component({
  selector: 'app-weather-country-details',
  templateUrl: './weather-country-details.component.html',
  styleUrls: ['./weather-country-details.component.css']
})
export class WeatherCountryDetailsComponent implements OnInit {
  icon = 'http://openweathermap.org/img/wn/';
  iconPart2 = '@2x.png';
  dataToBeDisplay: any = {
    main: {
      temp: 0,
      tempMin: 0,
      tempMax: 0
    },
    icon: ' ',
    wind: {
      speed: 0
    },
    weather: {
      description: ' '
    }
  };
  dark = false;
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
              private weatherService: OpenWeatherApiService) { }

  ngOnInit() {
    if (this.isDayOrNight() > 17) {
      this.dark = true;
    }
    if (this.data) {
      // kerkohen te dhenat per kete pozicion nga servisi openWeatherMAP
       this.weatherService.findWeather(this.data.lat, this.data.lng).subscribe(res => {
         this.icon = this.icon + '' + res.weather[0].icon + '' + this.iconPart2;
         this.dataToBeDisplay.main = {
           temp: this.convertFromKelvinToCelcius(res.main.temp),
           tempMin: this.convertFromKelvinToCelcius(res.main.temp_min),
           tempMax: this.convertFromKelvinToCelcius(res.main.temp_max)
         };
         this.dataToBeDisplay.wind = {
           speed: res.wind.speed,
         };
         this.dataToBeDisplay.weather = {
           description: res.weather[0].description,
         };
         this.dataToBeDisplay.icon = res.weather[0].icon;
         console.log('hyn');
         console.log(res);
       });
    }
  }
      convertFromKelvinToCelcius(fahr: number) {
        return (fahr - 273.15);
      }
      isDayOrNight() {
        const d = new Date();
        const n = d.getHours();
        return n;
      }
}
