import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  test = 'http://openweathermap.org/img/wn/13d@2x.png';

  constructor() { }

  ngOnInit() {
  }

}
