import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WeatherCountryDetailsComponent } from './weather-country-details.component';

describe('WeatherCountryDetailsComponent', () => {
  let component: WeatherCountryDetailsComponent;
  let fixture: ComponentFixture<WeatherCountryDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WeatherCountryDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WeatherCountryDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
