import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClientModule} from '@angular/common/http';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {LeafletModule} from '@asymmetrik/ngx-leaflet';
import { WeatherCountryDetailsComponent } from './weather-country-details/weather-country-details.component';
import {MatDialogModule} from '@angular/material/dialog';
import { TestComponent } from './test/test.component';
@NgModule({
  declarations: [
    AppComponent,
    WeatherCountryDetailsComponent,
    TestComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    LeafletModule,
    MatDialogModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  entryComponents: [WeatherCountryDetailsComponent]
})
export class AppModule { }
